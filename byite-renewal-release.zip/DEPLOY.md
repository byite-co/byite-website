# BYITE 리뉴얼 배포 노트 (2026-08-15)

## 교체/추가 (이 4개 + 이미지 1개)
- `index.html` — 리뉴얼 홈 (네온 다이얼 인터랙티브 + 사업 현황 + 문의/푸터)
- `ssambership-shot.jpg` — 쌤버십 카드 스크린샷 (index가 상대경로로 참조)
- `privacy.html` — ssambership.com/legal/privacy 로 즉시 이동(스토어 등록 URL 파손 방지용 유지)
- `sitemap.xml` — privacy 제외 갱신

## 그대로 유지
- `support.html`, `robots.txt`, `favicon*`, `apple-touch-icon.png`, `logo*.png/svg`, `og-image.png`

## 배포
main 에 push → Vercel 자동 배포. 배포 후 확인 3가지:
1. 라이브 전화번호가 02-6925-1883 으로 표시(기존 라이브는 구버전 1884였음)
2. /privacy.html 접속 시 쌤버십 처리방침으로 이동
3. 푸터 법정 표기(통신판매업신고 제2026-서울강남-04221호) 노출
